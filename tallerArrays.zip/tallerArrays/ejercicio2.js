const empleados = [
  { nombre: "Juan", sueldo: 1200000 },
  { nombre: "María", sueldo: 1500000 },
  { nombre: "Pedro", sueldo: 1100000 },
  { nombre: "Ana", sueldo: 2000000 },
  { nombre: "Valentina", sueldo: 10000000 },
  { nombre: "Jimena", sueldo: 3500000 }
];

const salarioMinimo = 1750000;

// Variables para acumular el texto y el dinero
let nominaInicial = "";
let nominaConAumento = "";
let sumaTotalEmpresa = 0;

// Recorremos el array de empleados
for (let i = 0; i < empleados.length; i++) {
  
  // --- PASO A: Guardar la lista inicial ---
  nominaInicial = nominaInicial + "<li>" + empleados[i].nombre + ": $" + empleados[i].sueldo + "</li>";

  // --- PASO B: Calcular aumento si aplica ---
  let sueldoFinal = empleados[i].sueldo;
  
  if (empleados[i].sueldo < salarioMinimo) {
    // Calculamos el 10% y lo sumamos
    sueldoFinal = empleados[i].sueldo * 1.10;
  }

  // --- PASO C: Guardar la lista con aumentos ---
  nominaConAumento = nominaConAumento + "<li>" + empleados[i].nombre + ": $" + sueldoFinal.toFixed(0) + "</li>";

  // --- PASO D: Ir sumando al total de la empresa ---
  sumaTotalEmpresa = sumaTotalEmpresa + sueldoFinal;
}

// --- MOSTRAR TODO EN LA PÁGINA ---
document.getElementById("listaInicial").innerHTML = nominaInicial;
document.getElementById("listaConAumento").innerHTML = nominaConAumento;
document.getElementById("totalPago").innerHTML = "Total a pagar este mes: $" + sumaTotalEmpresa;