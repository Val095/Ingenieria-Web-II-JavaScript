//declarar array con datos de los pasajeros
const pasajeros = [
  { nombre: "Carlos", edad: 25, pasaporte: true, asistencia: false },
  { nombre: "Elena", edad: 19, pasaporte: true, asistencia: true },
  { nombre: "Santi", edad: 17, pasaporte: true, asistencia: false },
  { nombre: "Lucía", edad: 30, pasaporte: false, asistencia: false }
];

let htmlPasajeros = "";
let todosMayores = true; // Asumimos que todos son mayores
let alguienConAsistencia = false; // Asumimos que nadie necesita asistencia

for (let i = 0; i < pasajeros.length; i++) {
  // mostrar la lista con todos los pasajeros y su estado de pasaporte
  let estadoPasaporte = pasajeros[i].pasaporte ? "Vigente" : "Vencido";
  htmlPasajeros = htmlPasajeros + "<li>" + pasajeros[i].nombre + " (" + pasajeros[i].edad + " años) - Pasaporte: " + estadoPasaporte + "</li>";

  //Verificar si hay algún menor de edad (cambia la bandera de 'todos')
  if (pasajeros[i].edad < 18) {
    todosMayores = false;
  }

  //Verificar si alguien necesita asistencia (cambia la bandera de 'alguno')
  if (pasajeros[i].asistencia === true) {
    alguienConAsistencia = true;
  }
}

//Mensaje final concatenando los resultados de las validaciones anteriores
let mensajeFinal = "";

if (todosMayores === true) {
  mensajeFinal = mensajeFinal + "<p style='color: green;'>✅ Todos los pasajeros son mayores de edad.</p>";
} else {
  mensajeFinal = mensajeFinal + "<p style='color: red;'>❌ Hay menores de edad en el grupo.</p>";
}

if (alguienConAsistencia === true) {
  mensajeFinal = mensajeFinal + "<p style='color: blue;'>ℹ️ Atención: Se requiere personal de asistencia para el embarque.</p>";
} else {
  mensajeFinal = mensajeFinal + "<p>ℹ️ No se requiere asistencia especial.</p>";
}

// mostrar el mensaje en la pagina usando innerHTML y con el id de los elementos
document.getElementById("listaPasajeros").innerHTML = htmlPasajeros;
document.getElementById("resultadoValidacion").innerHTML = mensajeFinal;