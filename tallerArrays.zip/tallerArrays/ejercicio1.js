//declarar el array de los productos con sus precios y su stock
const productos = [
  { nombre: "Teclado Mecánico", precio: 120, stock: 5 },
  { nombre: "Mouse Pad", precio: 15, stock: 10 },
  { nombre: "Monitor 4K", precio: 350, stock: 0 },
  { nombre: "Auriculares Pro", precio: 180, stock: 3 },
  { nombre: "Cable USB", precio: 110, stock: 8 }
];

// Variables para acumular el texto 
let contenidoTotal = "";
let contenidoFiltrado = "";

// mostrar la lista completa con un cico for
for (let i = 0; i < productos.length; i++) {
  // Concatenamos etiquetas <li> con el nombre y precio usando 
  contenidoTotal = contenidoTotal + "<li>" + productos[i].nombre + " - $" + productos[i].precio + " - " + "<b>" +productos[i].stock + " unidades disponibles " + "</b>" + "</li>";
}

//recorrer cada producto con un ciclo for y filtrar con un condicional if
for (let i = 0; i < productos.length; i++) {
  if (productos[i].precio > 100 && productos[i].stock > 0) {
    // Solo sumamos a esta variable si cumple la condición
    contenidoFiltrado = contenidoFiltrado + "<li>" + productos[i].nombre + ": $" + productos[i].precio + "</li>";
  }
}

//mostrar el resultado en la pagina usando innerHTML y con el id de los elementos
document.getElementById("listaTotal").innerHTML = contenidoTotal;
document.getElementById("listaFiltrados").innerHTML = contenidoFiltrado;