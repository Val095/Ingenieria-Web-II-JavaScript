//declarar el array de las habitaciones con su id, tipo y si estan ocupadas
const habitaciones = [
  { id: 101, tipo: "Sencilla", ocupada: false },
  { id: 102, tipo: "Doble", ocupada: true },
  { id: 103, tipo: "Suite", ocupada: false },
  { id: 104, tipo: "Matrimonial", ocupada: true }
];

//funcion que recibe el ID de una habitacion y devuelve sus detalles
function buscarHabitacion() {
  // Obtener el ID que el usuario escribió y convertirlo a numero
  let idBuscado = Number(document.getElementById("inputID").value);
  let mensaje = "";
  let encontrada = false;

  //recorrer el array con un ciclo for para buscar el ID
  for (let i = 0; i < habitaciones.length; i++) {
    
    //Validar si el ID del array es igual al ID que el usuario ingreso
    if (habitaciones[i].id === idBuscado) {
      encontrada = true; // ¡La encontramos!

      //Validar si la habitacion con dicho ID esta ocupada o no
      if (habitaciones[i].ocupada === false) {
        //Si esta desocupada mostrar un mensaje con el numero y qeu si esta disponible
        mensaje = "✅ DETALLES: Habitación " + habitaciones[i].id + 
                  " (" + habitaciones[i].tipo + ") está DISPONIBLE.";
      } else {
        //si esta ocupada mostrar un mensaje de error con el numero y que esta ocupada
        mensaje = "❌ ERROR: La habitación " + habitaciones[i].id + " ya está ocupada.";
      }
      
      // Como ya la encontramos, rompemos el ciclo para no seguir buscando
      break; 
    }
  }

  //si despues del ciclo no se encuentra nada, es decir que el id es invlado, mostrar un mensaje de error.
  if (encontrada === false) {
    mensaje = "⚠️ ERROR: El ID " + idBuscado + " no existe en el sistema.";
  }

  //Mostrar el mensaje en la página
  document.getElementById("resultadoBusqueda").innerHTML = mensaje;
}