//declarar el array de las visualizaciones con datos erroneos
const visualizaciones = [450, null, 1200, "error", 800, 2100, 950];

// declarar otro array donde estaran los datos sin errores
let datosLimpios = [];

for (let i = 0; i < visualizaciones.length; i++) {
  // Verificamos que sea un número y que no sea nulo
  if (typeof visualizaciones[i] === "number" && visualizaciones[i] !== null) {
    datosLimpios.push(visualizaciones[i]);
  }
}

//ordenar los valores de mayor a menor usando el metodo sort
// El método sort necesita una función de comparación para números
datosLimpios.sort(function(a, b) {
  return b - a; // De mayor a menor
});

//calcular el promedio de vistas y almacenar el resultado en una variable
let sumaVistas = 0;
for (let j = 0; j < datosLimpios.length; j++) {
    //sumar cada valor del array de datos limpios al total de vistas
  sumaVistas = sumaVistas + datosLimpios[j];
}
//variable para almacenar el promedio de vistas diarias
let promedio = sumaVistas / datosLimpios.length;

//mostrar los resultados en la p[agina usando innerHTML y con el id de los elementos
let mensaje = "<h4>Resultados del Análisis:</h4>";
mensaje = mensaje + "<p>✅ <strong>Datos limpios y ordenados:</strong> " + datosLimpios.join(" - ") + "</p>";
mensaje = mensaje + "<p>📊 <strong>Promedio de vistas diarias:</strong> " + promedio.toFixed(0) + "</p>";

document.getElementById("resultadoAnalitica").innerHTML = mensaje;