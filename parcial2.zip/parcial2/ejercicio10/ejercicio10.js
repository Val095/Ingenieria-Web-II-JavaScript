// Validación preventiva de formulario

const form = document.getElementById('contact-form');
const emailInput = document.getElementById('email');
const phoneInput = document.getElementById('phone');
const submitBtn = document.getElementById('submit-btn');
const emailError = document.getElementById('email-error');
const phoneError = document.getElementById('phone-error');

// Función para validar email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Función para validar teléfono (solo números, al menos 7 dígitos)
function isValidPhone(phone) {
    const phoneRegex = /^\d{7,}$/;
    return phoneRegex.test(phone.replace(/\s|-/g, ''));
}

// Función para validar todo el formulario
function validateForm() {
    const emailValid = isValidEmail(emailInput.value);
    const phoneValid = isValidPhone(phoneInput.value);

    // Mostrar/ocultar errores
    emailError.textContent = emailValid ? '' : 'Correo inválido';
    phoneError.textContent = phoneValid ? '' : 'Teléfono inválido (mínimo 7 dígitos)';

    // Habilitar/deshabilitar botón
    submitBtn.disabled = !(emailValid && phoneValid);
}

// Eventos de input para validación en tiempo real
emailInput.addEventListener('input', validateForm);
phoneInput.addEventListener('input', validateForm);

// Prevenir envío si no es válido (aunque el botón esté deshabilitado)
form.addEventListener('submit', (e) => {
    if (submitBtn.disabled) {
        e.preventDefault();
        alert('Por favor, completa correctamente todos los campos.');
    } else {
        e.preventDefault(); // Evitar recarga de página
        alert('Formulario enviado correctamente (simulado).');
    }
});