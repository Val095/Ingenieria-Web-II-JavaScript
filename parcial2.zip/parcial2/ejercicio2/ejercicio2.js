//Declaarar variables para el input y el texto de la contraseña
const passwordInput = document.getElementById('passwordInput');
const strengthText = document.getElementById('strengthText');

//Agregar un evento al input para evaluar la fortaleza de la contraseña
passwordInput.addEventListener('input', () => {
const password = passwordInput.value;
if (password.length < 5) {
    strengthText.textContent = 'Débil';
    strengthText.style.color = 'red';
} else if (password.length <= 10) {
    strengthText.textContent = 'Media';
    strengthText.style.color = 'orange';
} else {
    strengthText.textContent = 'Fuerte';
    strengthText.style.color = 'green';
}
});