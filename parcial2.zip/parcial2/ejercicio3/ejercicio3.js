// Mostrar imagen en modal al hacer clic en miniaturas

const thumbnails = document.querySelectorAll('.thumb');
const modal = document.getElementById('modal');
const modalImg = document.getElementById('modal-img');
const modalClose = document.getElementById('modal-close');

thumbnails.forEach(img => {
    img.addEventListener('click', () => {
        modalImg.src = img.src; // la misma imagen en grande
        modalImg.alt = img.alt;
        modal.style.display = 'block';
    });
});

// cerrar modal con el botón
modalClose.addEventListener('click', () => {
    modal.style.display = 'none';
});

// cerrar modal al hacer clic fuera de la imagen
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});