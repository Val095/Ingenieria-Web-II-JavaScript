//Declarar variables para el campo de búsqueda, la lista de países y los elementos de la lista
const searchInput = document.getElementById('search-input');
const countryList = document.getElementById('country-list');
const countries = countryList.getElementsByTagName('li');

//Agregar un evento de entrada al campo de búsqueda para filtrar la lista de países
const noResults = document.getElementById('no-results');

searchInput.addEventListener('input', function() {
    const filter = searchInput.value.toLowerCase();
    let anyVisible = false;
    for (let i = 0; i < countries.length; i++) {
        const countryName = countries[i].textContent.toLowerCase();
        if (countryName.includes(filter) && filter !== '') {
            countries[i].style.display = '';
            anyVisible = true;
        } else if (countryName.includes(filter) && filter === '') {
            //cuando el input este vacio mostrar todos los paises
            countries[i].style.display = '';
            anyVisible = true;
        } else {
            countries[i].style.display = 'none';
        }
    }

    // Mostrar u ocultar mensaje de no resultados
    if (!anyVisible) {
        noResults.style.display = 'block';
    } else {
        noResults.style.display = 'none';
    }
});