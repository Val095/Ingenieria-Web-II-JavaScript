const PARAGRAPHS = [
    "La memoria funciona de manera similar. Cada recuerdo recuperado se reescribe levemente, se contamina con el presente, se enriquece o empobrece según el estado de ánimo del que recuerda. No existe el archivo puro; existe solo la relectura permanente.",
    "Walter Benjamin intuía que el flâneur —ese paseante ocioso de la ciudad moderna— era en realidad un lector. Las fachadas, los escaparates, los rostros: todo texto que se descifra al caminar sin rumbo fijo, con la atención flotante que Freud llamaba «libremente fluctuante».",
    "Borges convirtió esa intuición en geografía: la Biblioteca de Babel no es una metáfora de la abundancia sino del desplazamiento infinito. En ella no hay fin porque tampoco hay principio; cada hexágono remite a otro y el lector se convierte en el laberinto mismo.",
    "La pantalla digital recuperó paradójicamente la forma del rollo. El scroll —esa palabra que en inglés significa precisamente 'rollo'— nos devolvió el gesto continuo, la lectura sin corte. Pero lo llenó de interrupciones invisibles: el algoritmo que decide qué sigue.",
    "Porque leer sin fin no es lo mismo que leer sin forma. El río tiene orillas aunque no tenga represa. La diferencia entre el flujo y el caos es la conciencia del cauce: saber que uno se mueve, y hacia dónde.",
    "En las tradiciones orales, el narrador podía extenderse indefinidamente mientras la audiencia permaneciera atenta. El silencio del oyente era el límite real del relato. Aquí también la atención era el borde, no la página.",
    "Los monjes copistas medievales insertan colofones al final de sus manuscritos: pequeñas notas de alivio, a veces de humor, donde celebran el fin del trabajo. «Deo gratias», escriben. La gratitud implica que algo ha terminado, que el esfuerzo tuvo remate.",
    "Pero el lector que llega a esa última línea ya ha comenzado a leer otra cosa: la huella del libro en su propia vida, la conversación que sostendrá, el matiz que cambiará su vocabulario. El texto termina; la lectura no.",
    "Proust entendía que recuperar el tiempo perdido no significaba repetirlo sino comprenderlo por primera vez. Sus siete volúmenes son un círculo: el narrador que en la última página se dispone a escribir la primera. La escritura como forma de leer la propia existencia.",
    "La ciencia del siglo XX descubrió que el universo se expande, que sus bordes retroceden más rápido de lo que la luz puede alcanzarlos. Hay cosmos que nunca podremos observar porque se alejan a velocidad mayor que nuestra capacidad de mirar. Los libros también tienen ese horizonte.",
    "Leer es, en última instancia, un acto de hospitalidad. Se abre la puerta a una voz que no es la propia, se le cede espacio en la cabeza, se le permite reorganizar los muebles. Los mejores libros dejan la casa irreconocible.",
    "Y sin embargo uno vuelve. Relee. Encuentra en la página conocida algo que no estaba, o que estaba y no se veía. El texto no cambió; cambió el ojo que lo recorre. Esa es quizás la única forma de infinito que el ser humano puede tocar con las manos.",
    "Toda escritura aspira en secreto a ser interrumpida. El punto y aparte es una invitación a que el lector complete; el capítulo, una pausa en la que el autor confía que el otro no cierre el libro. Escribir es apostar por la continuidad ajena.",
    "Dicen que los grandes lectores tienen mala memoria para los argumentos pero excelente para los climas. No recuerdan qué pasó, sino cómo olía la página, qué hora era, dónde estaban. El libro como lugar más que como contenido.",
    "Quizás por eso leer en pantalla se siente diferente: el lugar es siempre el mismo —ese rectángulo luminoso— y el cuerpo no acumula la postura particular de aquel sillón, aquella tarde, aquel olor a lluvia. El espacio forma parte del texto.",
    "Llegamos siempre al mismo punto: leer es vivir en paralelo. Dos tiempos, dos cuerpos, dos voces que coexisten sin fundirse del todo. Esa tensión es la literatura. Y la tensión, por definición, no se resuelve: se sostiene.",
  ];

  let pool = [...PARAGRAPHS]; // copia mutable
  let addedCount = 0;
  let loading = false;

  const content = document.getElementById('content');
  const loader  = document.getElementById('loader');
  const badge   = document.getElementById('counter-badge');

  function getNextThree() {
    if (pool.length < 3) pool = [...PARAGRAPHS]; // recicla si se agota
    return pool.splice(0, 3);
  }

  function appendParagraphs() {
    if (loading) return;
    loading = true;
    loader.style.display = 'block';

    setTimeout(() => {
      // Separador decorativo
      const sep = document.createElement('p');
      sep.className = 'section-break';
      sep.textContent = '· · ·';
      content.appendChild(sep);

      const texts = getNextThree();
      texts.forEach((text, i) => {
        const p = document.createElement('p');
        p.textContent = text;
        p.className = 'new-block';
        p.style.animationDelay = `${i * 0.12}s`;
        content.appendChild(p);
        addedCount++;
      });

      badge.textContent = `+${addedCount} párrafo${addedCount !== 1 ? 's' : ''} añadido${addedCount !== 1 ? 's' : ''}`;

      loader.style.display = 'none';
      loading = false;
    }, 700); // pequeño delay para mostrar el loader
  }

  // Detección de scroll al fondo 
  function nearBottom() {
    const scrollTop    = window.scrollY || document.documentElement.scrollTop;
    const windowHeight = window.innerHeight;
    const docHeight    = document.documentElement.scrollHeight;
    return scrollTop + windowHeight >= docHeight - 60; // 60px de margen
  }

  window.addEventListener('scroll', () => {
    if (nearBottom()) appendParagraphs();
  }, { passive: true });