//Declarar las variables para el input, el botón y la lista
const agregarBtn = document.getElementById('agregarBtn');
const tareaInput = document.getElementById('tareaInput');
const tareasList = document.getElementById('tareasList');
//Agregar un evento al botón para agregar tareas a la lista
agregarBtn.addEventListener('click', () => {
const tareaTexto = tareaInput.value.trim();
//Verificar que el input no esté vacío
if (tareaTexto !== '') {
    const li = document.createElement('li');
    li.textContent = tareaTexto;
    //Crear el botón de eliminar para cada tarea
    const eliminarBtn = document.createElement('button');
    eliminarBtn.textContent = 'Eliminar';
    eliminarBtn.addEventListener('click', () => {
        tareasList.removeChild(li);
    });
    // Agregar el botón de eliminar a la tarea y luego agregar la tarea a la lista
    li.appendChild(eliminarBtn);
    tareasList.appendChild(li);
    tareaInput.value = '';
}
});