// Accordion FAQ: al hacer clic en una pregunta se muestra su respuesta y se ocultan las demás

const faq = document.getElementById('faq');
const items = faq.getElementsByClassName('item');

// recorrer cada item y asignar manejador al botón de pregunta
for (let i = 0; i < items.length; i++) {
    const questionBtn = items[i].querySelector('.question');
    const answerPara = items[i].querySelector('.answer');

    questionBtn.addEventListener('click', function() {
        // cerrar todas las respuestas primero
        for (let j = 0; j < items.length; j++) {
            const ans = items[j].querySelector('.answer');
            if (ans !== answerPara) {
                ans.style.display = 'none';
            }
        }
        // alternar la respuesta actual
        if (answerPara.style.display === 'none' || answerPara.style.display === '') {
            answerPara.style.display = 'block';
        } else {
            answerPara.style.display = 'none';
        }
    });
}