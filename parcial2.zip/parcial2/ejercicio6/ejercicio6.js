//Declarar variables para el botón de inicio, el campo de entrada de segundos y la pantalla 
// de cuenta regresiva
const startButton = document.getElementById('start-button');    
const secondsInput = document.getElementById('seconds-input');
const countdownDisplay = document.getElementById('countdown-display');

//Agregar un evento de clic al botón de inicio para iniciar la cuenta regresiva
startButton.addEventListener('click', () => {
let seconds = parseInt(secondsInput.value);

//Validar que el valor ingresado sea un número válido y no negativo
    if (isNaN(seconds) || seconds < 0) {
        alert('Por favor, ingrese un número válido de segundos.');
        return;
    }
    countdownDisplay.textContent = seconds;
    const intervalId = setInterval(() => {
        seconds--;
        countdownDisplay.textContent = seconds;
        if (seconds <= 0) {
            clearInterval(intervalId);
            alert('¡Tiempo terminado!');
        }
    }, 1000);
});

