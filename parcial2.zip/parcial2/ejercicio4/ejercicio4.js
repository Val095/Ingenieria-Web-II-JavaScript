//Declarar variables para el cuerpo del documento y el botón de alternancia
const body = document.body;
const toggleButton = document.getElementById("dark-mode-toggle");
//Agregar un evento de clic al botón para alternar el modo oscuro
    toggleButton.addEventListener("click", () => {
        body.classList.toggle("dark-mode");
        if (body.classList.contains("dark-mode")) {
            toggleButton.textContent = "Desactivar Modo Oscuro";
        } else {
            toggleButton.textContent = "Activar Modo Oscuro";
        }
        });