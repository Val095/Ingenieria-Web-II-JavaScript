// Obtener todos los inputs de cantidad
const cantidadInputs = document.querySelectorAll('.cantidad');

// Función para calcular el total
function calcularTotal() {
    let total = 0;
    
    cantidadInputs.forEach(input => {
        const precio = parseInt(input.getAttribute('data-precio'));
        const cantidad = parseInt(input.value) || 0;
        const subtotal = precio * cantidad;
        
        // Actualizar el subtotal en la fila
        input.closest('tr').querySelector('.subtotal').textContent = '$' + subtotal;
        
        // Sumar al total
        total += subtotal;
    });
    
    // Actualizar el total final
    document.getElementById('total').textContent = '$' + total;
}

// Agregar event listeners a todos los inputs
cantidadInputs.forEach(input => {
    input.addEventListener('change', calcularTotal);
    input.addEventListener('input', calcularTotal);
});

// Calcular el total inicial
calcularTotal();